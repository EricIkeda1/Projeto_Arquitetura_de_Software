from django.apps import AppConfig


class CadastroAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cadastro_app'
